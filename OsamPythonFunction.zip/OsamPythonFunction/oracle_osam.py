# -*- coding: utf-8 -*-
"""
Created on Tue Dec 14 13:45:57 2021

@author: naichowdhury

Logic for the OSAM Cloud SOD Analysis
"""
import concurrent.futures
import copy, io, tempfile, os
import logging
import sys
import time
import configparser as conf
import pandas as pd
from pymongo import MongoClient
from datetime import datetime, timedelta
# from azure.storage.blob import BlobPermissions
# from azure.storage.blob.baseblobservice import BaseBlobService
from azure.storage.blob import BlobServiceClient, BlobClient, generate_blob_sas, BlobSasPermissions
import yaml
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
logging.basicConfig(filename='../dfte-oracle-osam/logs\\SOD_cloud.log', filemode='a', level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s: %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p')

# Mongo DB client creation
with open('OsamPythonFunction/properties.yaml') as config:
    yaml_reader = (yaml.safe_load(config))
    # print(yaml_reader['Mongo_credentials']['username'])

username = yaml_reader['Mongo_credentials']['username']
password = yaml_reader['Mongo_credentials']['password']
db_name = yaml_reader['Mongo_db']['db_name']
cluster_name = yaml_reader['Mongo_db']['collection_name']
CONNECTION_STRING = yaml_reader['Dev_env']['CONNECTION_STRING']
container_name = yaml_reader['Dev_env']['container_name']
STORAGEACCOUNTNAME = yaml_reader['Dev_env']['STORAGEACCOUNTNAME']
STORAGEACCOUNTKEY = yaml_reader['Dev_env']['STORAGEACCOUNTKEY']

conn_str = "mongodb://" + username + ":" + password + "@" + db_name + ".mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@" + db_name + "@"


cluster = MongoClient(conn_str)
# cluster = MongoClient("mongodb://dftedevcos:bVWBGXhIHLufpJkrKfIZ4X1mifXPpfZtsPwoMwMPW89pawa0mhvH1qjRRHAl1C3aMIvqPpKbo5n0HqPupNyqEQ==@dftedevcos.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@dftedevcos@")

db = cluster[db_name]
collection = db[cluster_name]

blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
container_client = blob_service_client.get_container_client(container_name)
errors_list = []

# LOCALFILENAME= '/home/data/test_11.xlsx'
# BLOBNAME= 'Cloud Role Matrix - Input.xlsx'

def read_file_from_azure(file_name):
    # #from pathlib import Path
    # #data= str(Path.home()) + "/data"
    # LOCALFILENAME = os.path.join(tempfile.gettempdir(), 'temp.xlsx')
    # #writer = pd.ExcelWriter(LOCALFILENAME)
    # #writer.save()
    # #filename = "test_nairit_1.xlsx"
    # #blob_client = blob_service_client.get_blob_client(container_name, filename)
    # blob = BlobClient.from_connection_string(conn_str="DefaultEndpointsProtocol=https;AccountName=azusedcslogprdstocgfpqs;AccountKey=6c7KRKF4MAFn/VVC53tXihX1e4VfhJdFezqA0HBvhastQxwYGa1cvLGNNFFJxC+nffnyUv0Y1as5+ASt9bdi6Q==;EndpointSuffix=core.windows.net", container_name="dftedev", blob_name=file_name)
    # print('start')
    # with open(LOCALFILENAME, "wb") as my_blob:
    #     blob_data = blob.download_blob()
    #     blob_data.readinto(my_blob)
    # # LOCALFILE is the file path
    # #dataframe_blobdata = pd.read_excel(LOCALFILENAME)
    # return LOCALFILENAME
    try:
        logging.info("Started reading file from Azure: " + str(file_name))
        sas_blob = generate_blob_sas(account_name=STORAGEACCOUNTNAME,
                                     container_name=container_name,
                                     blob_name=file_name,
                                     account_key=STORAGEACCOUNTKEY,
                                     permission=BlobSasPermissions(read=True),
                                     expiry=datetime.utcnow() + timedelta(hours=1))

        # blob = get_blob_sas(account_name,account_key, container_name, blob_name)
        url = 'https://' + STORAGEACCOUNTNAME + '.blob.core.windows.net/' + container_name + '/' + file_name + '?' + sas_blob
        logging.info("Completed reading file from Azure: " + str(file_name))
        return url
    except Exception as e:
        logging.error("Read file from azure got failed: " + str(file_name))
        logging.error(type(e).__name__)
        errors_list.append(e)
        return e


def read_osam_input_excel(cloud_rule_file, role_design_files, user_to_role_file):
    """
    @author: naichowdhury
    reading the osam input files : cloud role matrix, OSAMSODRULESET,
    and roles to user input file, if required
    :return: dataframe containing the contents of the input files
    """
    # reading the cloud role matrix mapping file provided by the user
    try:
        logging.info("Started reading OSAM input Excel sheet")
        cloud_role_matrix_data = pd.DataFrame()
        cloud_role_matrix_file_list = role_design_files.split(",")
        for role_design_file in cloud_role_matrix_file_list:
            cloud_role_matrix_data = cloud_role_matrix_data.append(
                pd.read_excel(read_file_from_azure(role_design_file).replace(" ", "%20"), sheet_name='Cloud Role Matrix',
                              engine='openpyxl'))

        # reading the SOD Activity Mapping
        osam_sod_ruleset_data = pd.read_excel(read_file_from_azure(cloud_rule_file).replace(" ", "%20"),
                                              sheet_name='SOD Activity Mapping', skiprows=8, engine='openpyxl')

        # reading the SOD Rules
        osam_sod_rule_data = pd.read_excel(read_file_from_azure(cloud_rule_file).replace(" ", "%20"),
                                           sheet_name='SOD Rules', skiprows=8, engine='openpyxl')

        # This is an optional file, If optional, it comes as NA
        osam_roles_to_user = pd.DataFrame()
        if user_to_role_file != 'NA':
            osam_roles_to_user = pd.read_excel(read_file_from_azure(user_to_role_file).replace(" ", "%20"),
                                               sheet_name='Assign Roles or Resps', skiprows=8,
                                               keep_default_na=False, engine='openpyxl')

            osam_roles_to_user.dropna()

        logging.info('reading files complete')

        return cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data, osam_roles_to_user

    except Exception as e:
        logging.error("Reading osam input excel file failed")
        logging.error(type(e).__name__)
        errors_list.append(e)
        return e

def osam_role_conflict_validation(cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data,
                                  cloud_role_matrix_role_columns, final_sod_conflicts_dataframe,
                                  final_activty_mapping_dataframe, activity_mapping_flag):
    """
    @author: naichowdhury
    logic to validate the sod conflict for rules mentioned in the
    cloud role matrix input file
    :param cloud_role_matrix_data:
    :type cloud_role_matrix_data:
    :param osam_sod_ruleset_data:
    :type osam_sod_ruleset_data:
    :param osam_sod_rule_data:
    :type osam_sod_rule_data:
    :param cloud_role_matrix_role_columns:
    :type cloud_role_matrix_role_columns:
    :param final_sod_conflicts_dataframe:
    :type final_sod_conflicts_dataframe:
    :param final_activty_mapping_dataframe:
    :type final_activty_mapping_dataframe:
    :param activity_mapping_flag:
    :type activity_mapping_flag:
    :return: the final processed dataframe of SOD Conflict details for role and Activity Mapping details
    :rtype:
    """
    try:
        for role in cloud_role_matrix_role_columns:
            cloud_role_matrix_data_role = cloud_role_matrix_data.loc[cloud_role_matrix_data[role] == 'X']

            # entitlement validation starts
            cloud_role_matrix_entitlement_name_data = cloud_role_matrix_data_role["ENTITLEMENT-NAME"].tolist()

            cloud_role_matrix_entitlement_name_data = list(set(cloud_role_matrix_entitlement_name_data))

            # osam_sod_ruleset_columns = list(osam_sod_ruleset_data.columns)

            # # group by SOGN to accumulate multiple records
            # osam_sod_ruleset_dict = osam_sod_ruleset_data.set_index(
            #     'Security Object Group Name').groupby('Security Object Group Name').apply(
            #     lambda x: x.to_dict('records'))
            #
            # osam_sod_ruleset_filtered_dict = {}

            osam_sod_ruleset_filtered = pd.DataFrame()
            conflict_index_list = []

            for entitlement in cloud_role_matrix_entitlement_name_data:

                if entitlement in osam_sod_ruleset_data['Security Object Group Name'].to_list():
                    matching_values = osam_sod_ruleset_data[
                                          'Security Object Group Name'].values == entitlement
                    conflict_index_list.append(entitlement)
                    osam_sod_ruleset_filtered = osam_sod_ruleset_filtered.append(
                        osam_sod_ruleset_data[matching_values])

            # Filtering for Activity Mapping
            if activity_mapping_flag:
                cloud_role_matrix_data_role_activity_mapping = cloud_role_matrix_data_role[
                    cloud_role_matrix_data_role['ENTITLEMENT-NAME'].isin(conflict_index_list)]
                # cloud_role_matrix_data_role_activity_mapping =
                osam_activity_mapping_filtered = copy.deepcopy(osam_sod_ruleset_filtered)
                osam_activity_mapping_filtered.rename(columns={'Security Object Group Name': 'ENTITLEMENT-NAME'},
                                                      inplace=True)

                cloud_role_matrix_data_role_activity_mapping = cloud_role_matrix_data_role_activity_mapping.drop(
                    cloud_role_matrix_data_role_activity_mapping.iloc[:, 13:],
                    axis=1)

                if 'ENTITLEMENT-NAME' not in osam_activity_mapping_filtered:
                    osam_activity_mapping_filtered['ENTITLEMENT-NAME'] = ''
                temp_activity_mapping_dataframe = pd.merge(osam_activity_mapping_filtered,
                                                               cloud_role_matrix_data_role_activity_mapping,
                                                               on='ENTITLEMENT-NAME')

                temp_activity_mapping_dataframe['Role or User Name'] = str(role)
                temp_activity_mapping_dataframe['Object Type'] = str('Role')
                temp_activity_mapping_dataframe['Role Name'] = str(role)
                temp_activity_mapping_dataframe['Navigation Path'] = temp_activity_mapping_dataframe[
                                                                         'Role or User Name'].astype(str) + str('~') + \
                                                                     temp_activity_mapping_dataframe[
                                                                         'INHERITED-ROLE-HIERARCHY']

                # temp_activity_mapping_dataframe = temp_activity_mapping_dataframe.drop(['Rule Name'], axis=1)

                final_activty_mapping_dataframe = final_activty_mapping_dataframe.append(temp_activity_mapping_dataframe)

            osam_sod_ruleset_activity_list = []

            if True != osam_sod_ruleset_filtered.empty:
                osam_sod_ruleset_activity_list = osam_sod_ruleset_filtered['Activity Name'].tolist()

            # osam_sod_rule_data_dict = osam_sod_rule_data.set_index('Activity Name').T.to_dict()

            conflict_activity_list = []
            osam_sod_rule_data_filtered_dict = {}

            osam_sod_rule_data_filtered_df = pd.DataFrame()
            osam_sod_rule_conflict_df = pd.DataFrame()

            for activity in osam_sod_ruleset_activity_list:
                osam_sod_rule_data_filtered_df = osam_sod_rule_data_filtered_df.append(
                    osam_sod_rule_data.loc[osam_sod_rule_data['Activity Name'] == activity])
                # osam_sod_rule_conflict_df.append(osam_sod_rule_data_filtered_df[osam_sod_rule_data_filtered_df.duplicated('Rule Name')])

            if True != osam_sod_rule_data_filtered_df.empty:
                osam_sod_rule_data_filtered_dict = osam_sod_rule_data_filtered_df.set_index('Rule Name').groupby('Rule Name').apply(lambda x: x.to_dict('records'))

            unique_conflict_index_list = []
            unique_conflict_rule_list = []
            unique_correct_rule_list = []

            for key in osam_sod_rule_data_filtered_dict.keys():
                osam_sod_rule_data_filtered_dict[key] = list(set(
                    osam_sod_rule_data_filtered_df[osam_sod_rule_data_filtered_df['Rule Name'] == key][
                        'Activity Name'].values))

            for rule_key in osam_sod_rule_data_filtered_dict.keys():
                if len(osam_sod_rule_data_filtered_dict.get(rule_key)) == 1 and '&' not in rule_key:
                    for conflict_activity in osam_sod_rule_data_filtered_dict.get(rule_key):
                        unique_conflict_index_list.append(conflict_activity)
                        unique_conflict_rule_list.append(rule_key)
                if len(osam_sod_rule_data_filtered_dict.get(rule_key)) > 1:
                    for conflict_activity in osam_sod_rule_data_filtered_dict.get(rule_key):
                        unique_conflict_index_list.append(conflict_activity)
                        unique_conflict_rule_list.append(rule_key)
                else:
                    if '&' in rule_key:
                        unique_correct_rule_list.append(rule_key)

            for rule in unique_correct_rule_list:
                osam_sod_rule_data_filtered_dict.pop(rule)

            final_cloud_role_matrix_data = pd.DataFrame()
            confict_sec_obj_grp_df = pd.DataFrame()
            final_sod_rules = pd.DataFrame()
            final_sod_activity_mapping = pd.DataFrame()

            for conflict_index in unique_conflict_index_list:
                confict_sec_obj_grp_df = confict_sec_obj_grp_df.append(
                    osam_sod_ruleset_data.loc[osam_sod_ruleset_data['Activity Name'] == conflict_index])

            conflict_entitlement_list = []
            if True != confict_sec_obj_grp_df.empty:
                conflict_entitlement_list = list(set(confict_sec_obj_grp_df['Security Object Group Name'].tolist()))

            for conflict_entitlement in conflict_entitlement_list:
                final_cloud_role_matrix_data = final_cloud_role_matrix_data.append(
                    cloud_role_matrix_data_role.loc[
                        cloud_role_matrix_data_role['ENTITLEMENT-NAME'] == conflict_entitlement])
                final_sod_activity_mapping = final_sod_activity_mapping.append(
                    osam_sod_ruleset_data.loc[osam_sod_ruleset_data['Security Object Group Name'] == conflict_entitlement])

            unique_conflict_rule_list = list(set(unique_conflict_rule_list))
            for rule in unique_conflict_rule_list:
                final_sod_rules = final_sod_rules.append(osam_sod_rule_data.loc[osam_sod_rule_data['Rule Name'] == rule])

            # final_op_df = pd.concat([final_cloud_role_matrix_data, final_sod_activity_mapping, final_sod_rules], ignore_index=True, sort=True)

            # final_cloud_role_matrix_data = pd.DataFrame()
            # if True != final_cloud_role_matrix_data.empty:
            final_cloud_role_matrix_data = final_cloud_role_matrix_data.drop(final_cloud_role_matrix_data.iloc[:, 13:],
                                                                             axis=1)

            if True != final_sod_rules.empty and True != final_sod_activity_mapping.empty and True != final_cloud_role_matrix_data.empty:
                temp_op_dataframe = pd.merge(final_sod_rules, final_sod_activity_mapping, on='Activity Name')

                temp_op_dataframe.rename(columns={'Security Object Group Name': 'ENTITLEMENT-NAME'}, inplace=True)

                temp_op_dataframe = pd.merge(temp_op_dataframe, final_cloud_role_matrix_data, on='ENTITLEMENT-NAME')
                temp_op_dataframe['Role or User Name'] = str(role)
                temp_op_dataframe['Object Type'] = str('Role')
                temp_op_dataframe['Role Name'] = str(role)
                temp_op_dataframe['Navigation Path'] = temp_op_dataframe['Role or User Name'].astype(str) + str('~') + \
                                                       temp_op_dataframe['INHERITED-ROLE-HIERARCHY']

                final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.append(temp_op_dataframe)
        final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.drop_duplicates()
        return final_sod_conflicts_dataframe, final_activty_mapping_dataframe
    except Exception as e:
        logging.error("OSAM role conflict validation got failed")
        logging.error(type(e).__name__)
        errors_list.append(e)
        return e


def osam_user_conflict_validation(cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data,
                                  cloud_role_matrix_role_columns, final_sod_conflicts_dataframe,
                                  final_activity_mapping_dataframe, user_name, activity_mapping_flag):
    """
    @author: naichowdhury
    logic to process the sod conflict details for users, if the roles to user input
    is available
    :param cloud_role_matrix_data:
    :type cloud_role_matrix_data:
    :param osam_sod_ruleset_data:
    :type osam_sod_ruleset_data:
    :param osam_sod_rule_data:
    :type osam_sod_rule_data:
    :param cloud_role_matrix_role_columns:
    :type cloud_role_matrix_role_columns:
    :param final_sod_conflicts_dataframe:
    :type final_sod_conflicts_dataframe:
    :param final_activity_mapping_dataframe:
    :type final_activity_mapping_dataframe:
    :param user_name:
    :type user_name:
    :param activity_mapping_flag:
    :type activity_mapping_flag:
    :return: dataframes with the SOD Conflicts for user and Activity Mapping
    :rtype:
    """
    try:

        cloud_role_matrix_entitlement_name_data = []
        cloud_role_matrix_data_role_user_role = pd.DataFrame()
        for role in cloud_role_matrix_role_columns:
            if role in list(cloud_role_matrix_data.columns):
                cloud_role_matrix_data_role_user_role = cloud_role_matrix_data_role_user_role.append(
                    cloud_role_matrix_data.loc[cloud_role_matrix_data[role] == 'X'])

        if True != cloud_role_matrix_data_role_user_role.empty:
            # entitlement validation starts
            cloud_role_matrix_entitlement_name_data.extend(
                cloud_role_matrix_data_role_user_role["ENTITLEMENT-NAME"].tolist())

            cloud_role_matrix_entitlement_name_data = list(set(cloud_role_matrix_entitlement_name_data))

            osam_sod_ruleset_columns = list(osam_sod_ruleset_data.columns)

            osam_sod_ruleset_filtered = pd.DataFrame()
            conflict_index_list = []

            for entitlement in cloud_role_matrix_entitlement_name_data:

                if entitlement in osam_sod_ruleset_data['Security Object Group Name'].to_list():
                    matching_values = osam_sod_ruleset_data[
                                          'Security Object Group Name'].values == entitlement
                    conflict_index_list.append(entitlement)
                    osam_sod_ruleset_filtered = osam_sod_ruleset_filtered.append(
                        osam_sod_ruleset_data[matching_values])

            # Filtering for Activity Mapping
            if activity_mapping_flag:
                cloud_role_matrix_data_user_activity_mapping = cloud_role_matrix_data_role_user_role[
                    cloud_role_matrix_data_role_user_role['ENTITLEMENT-NAME'].isin(conflict_index_list)]
                # cloud_role_matrix_data_role_activity_mapping =
                osam_activity_mapping_filtered = copy.deepcopy(osam_sod_ruleset_filtered)
                osam_activity_mapping_filtered.rename(columns={'Security Object Group Name': 'ENTITLEMENT-NAME'},
                                                      inplace=True)
                cloud_role_matrix_data_user_activity_mapping = cloud_role_matrix_data_user_activity_mapping.drop(
                    cloud_role_matrix_data_user_activity_mapping.iloc[:, 13:],
                    axis=1)
                if 'ENTITLEMENT-NAME' not in osam_activity_mapping_filtered:
                    osam_activity_mapping_filtered['ENTITLEMENT-NAME'] = ''
                temp_activity_mapping_dataframe = pd.merge(osam_activity_mapping_filtered,
                                                               cloud_role_matrix_data_user_activity_mapping,
                                                               on='ENTITLEMENT-NAME')

                temp_activity_mapping_dataframe['Role Name'] = temp_activity_mapping_dataframe['ROLE NAME'].astype(str)
                temp_activity_mapping_dataframe['Role or User Name'] = str(user_name)
                temp_activity_mapping_dataframe['Object Type'] = str('User')
                temp_activity_mapping_dataframe['Navigation Path'] = str('User:') + str(user_name) + str('>') + \
                                                                     temp_activity_mapping_dataframe[
                                                                         'ROLE NAME'] + str(
                    '~') + temp_activity_mapping_dataframe['INHERITED-ROLE-HIERARCHY']

                # temp_activity_mapping_dataframe = temp_activity_mapping_dataframe.drop(['Rule Name'], axis=1)

                final_activity_mapping_dataframe = final_activity_mapping_dataframe.append(temp_activity_mapping_dataframe)

            osam_sod_ruleset_activity_list = []

            if True != osam_sod_ruleset_filtered.empty:
                osam_sod_ruleset_activity_list = osam_sod_ruleset_filtered['Activity Name'].tolist()

            osam_sod_rule_data_dict = osam_sod_rule_data.set_index('Activity Name').T.to_dict()

            conflict_activity_list = []
            osam_sod_rule_data_filtered_dict = {}

            osam_sod_rule_data_filtered_df = pd.DataFrame()
            osam_sod_rule_conflict_df = pd.DataFrame()

            for activity in osam_sod_ruleset_activity_list:
                osam_sod_rule_data_filtered_df = osam_sod_rule_data_filtered_df.append(
                    osam_sod_rule_data.loc[osam_sod_rule_data['Activity Name'] == activity])
                # osam_sod_rule_conflict_df.append(osam_sod_rule_data_filtered_df[osam_sod_rule_data_filtered_df.duplicated('Rule Name')])

            if True != osam_sod_rule_data_filtered_df.empty:
                osam_sod_rule_data_filtered_dict = osam_sod_rule_data_filtered_df.set_index('Rule Name').groupby('Rule Name').apply(lambda x: x.to_dict('records'))

            unique_conflict_index_list = []
            unique_conflict_rule_list = []
            unique_correct_rule_list = []

            for key in osam_sod_rule_data_filtered_dict.keys():
                osam_sod_rule_data_filtered_dict[key] = list(set(
                    osam_sod_rule_data_filtered_df[osam_sod_rule_data_filtered_df['Rule Name'] == key][
                        'Activity Name'].values))

            for rule_key in osam_sod_rule_data_filtered_dict.keys():
                if len(osam_sod_rule_data_filtered_dict.get(rule_key)) == 1 and '&' not in rule_key:
                    for conflict_activity in osam_sod_rule_data_filtered_dict.get(rule_key):
                        unique_conflict_index_list.append(conflict_activity)
                        unique_conflict_rule_list.append(rule_key)
                if len(osam_sod_rule_data_filtered_dict.get(rule_key)) > 1:
                    for conflict_activity in osam_sod_rule_data_filtered_dict.get(rule_key):
                        unique_conflict_index_list.append(conflict_activity)
                        unique_conflict_rule_list.append(rule_key)
                else:
                    if '&' in rule_key:
                        unique_correct_rule_list.append(rule_key)

            for rule in unique_correct_rule_list:
                osam_sod_rule_data_filtered_dict.pop(rule)

            final_cloud_role_matrix_data = pd.DataFrame()
            confict_sec_obj_grp_df = pd.DataFrame()
            final_sod_rules = pd.DataFrame()
            final_sod_activity_mapping = pd.DataFrame()

            for conflict_index in unique_conflict_index_list:
                confict_sec_obj_grp_df = confict_sec_obj_grp_df.append(
                    osam_sod_ruleset_data.loc[osam_sod_ruleset_data['Activity Name'] == conflict_index])

            conflict_entitlement_list = []
            if True != confict_sec_obj_grp_df.empty:
                conflict_entitlement_list = list(set(confict_sec_obj_grp_df['Security Object Group Name'].tolist()))

            for conflict_entitlement in conflict_entitlement_list:
                final_cloud_role_matrix_data = final_cloud_role_matrix_data.append(
                    cloud_role_matrix_data_role_user_role.loc[
                        cloud_role_matrix_data_role_user_role['ENTITLEMENT-NAME'] == conflict_entitlement])
                final_sod_activity_mapping = final_sod_activity_mapping.append(
                    osam_sod_ruleset_data.loc[osam_sod_ruleset_data['Security Object Group Name'] == conflict_entitlement])

            unique_conflict_rule_list = list(set(unique_conflict_rule_list))
            for rule in unique_conflict_rule_list:
                final_sod_rules = final_sod_rules.append(osam_sod_rule_data.loc[osam_sod_rule_data['Rule Name'] == rule])

            # final_op_df = pd.concat([final_cloud_role_matrix_data, final_sod_activity_mapping, final_sod_rules], ignore_index=True, sort=True)

            # final_cloud_role_matrix_data = pd.DataFrame()
            # if True != final_cloud_role_matrix_data.empty:
            final_cloud_role_matrix_data = final_cloud_role_matrix_data.drop(final_cloud_role_matrix_data.iloc[:, 13:],
                                                                             axis=1)

            if True != final_sod_rules.empty and True != final_sod_activity_mapping.empty and True != final_cloud_role_matrix_data.empty:
                temp_op_dataframe = pd.merge(final_sod_rules, final_sod_activity_mapping, on='Activity Name')

                temp_op_dataframe.rename(columns={'Security Object Group Name': 'ENTITLEMENT-NAME'}, inplace=True)

                temp_op_dataframe = pd.merge(temp_op_dataframe, final_cloud_role_matrix_data, on='ENTITLEMENT-NAME')
                temp_op_dataframe['Role Name'] = temp_op_dataframe['ROLE NAME'].astype(str)
                temp_op_dataframe['Role or User Name'] = str(user_name)
                temp_op_dataframe['Object Type'] = str('User')
                temp_op_dataframe['Navigation Path'] = str('User:') + str(user_name) + str('>') + temp_op_dataframe[
                    'ROLE NAME'] + str(
                    '~') + temp_op_dataframe['INHERITED-ROLE-HIERARCHY']

                final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.append(temp_op_dataframe)

                final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.drop(['ROLE NAME'], axis=1)
        final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.drop_duplicates()
        return final_sod_conflicts_dataframe, final_activity_mapping_dataframe
    except Exception as e:


        logging.error("OSAM User conflict validation got failed: ")
        logging.error(type(e).__name__)
        errors_list.append(e)
        return e


def split_process(osam_roles_to_user_dict, osam_roles_to_user, cloud_role_matrix_data, osam_sod_ruleset_data,
                  osam_sod_rule_data,
                  final_sod_conflicts_dataframe_user, final_activity_mapping_dataframe_user, activity_mapping_flag):
    process = []
    print("for loop length", len(osam_roles_to_user_dict.keys()))
    logging.info("Parallel process started")
    for key in osam_roles_to_user_dict.keys():
        user_role_list = list(set(
            osam_roles_to_user[osam_roles_to_user['User Name'] == str(key)][
                'Role or Responsibility Name'].values))
        # print(key)
        # print(val)
        final_sod_conflicts_dataframe_user, final_activity_mapping_dataframe_user = osam_user_conflict_validation(
            cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data,
            user_role_list,
            final_sod_conflicts_dataframe_user, final_activity_mapping_dataframe_user,
            str(key),
            activity_mapping_flag)
    # time.sleep(3)
    # return "Done sleep"
    return final_sod_conflicts_dataframe_user, final_activity_mapping_dataframe_user


def split_dict_equally(input_dict, chunks=2):
    "Splits dict by keys. Returns a list of dictionaries."
    # prep with empty dicts
    return_list = [dict() for idx in range(chunks)]
    idx = 0
    for k, v in input_dict.items():
        return_list[idx][k] = v
        if idx < chunks - 1:  # indexes start at 0
            idx += 1
        else:
            idx = 0
    return return_list


# entry point for the program execution flow
def osam_processing(cloud_rule_file, role_design_files, user_to_role_file, is_sod_needed_flag, is_activity_needed_flag,
                    output_file_sod, output_file_activity=None, req_id=None):
    """
    @author: naichowdhury
    the entry point for the  processing of SOD Conflicts & Activity Mapping
    :param cloud_rule_file:
    :type cloud_rule_file:
    :param role_design_files:
    :type role_design_files:
    :param user_to_role_file:
    :type user_to_role_file:
    :param is_sod_needed_flag:
    :type is_sod_needed_flag:
    :param is_activity_needed_flag:
    :type is_activity_needed_flag:
    :param output_file:
    :type output_file:
    :return: the output excel file with the SOD Conflicts and Activity Mapping details
    :rtype:
    """
    logging.info("Osam processing started")
    logging.info("Cloud rule file: " + cloud_rule_file)
    logging.info("role design files: " + role_design_files)
    logging.info("user to role file: " + user_to_role_file)
    logging.info("is sod needed flag: " + is_sod_needed_flag)
    logging.info("is activity needed flag: " + is_activity_needed_flag)
    logging.info("output file sod: " + output_file_sod)
    logging.info("output file activity: " + output_file_activity)
    logging.info("request id: " + req_id)
    start_time = time.time()
    try:
        if is_activity_needed_flag == 'Y':
            activity_mapping_flag = True
        else:
            activity_mapping_flag = False

        # Dataframe initialization for SOD Conflict
        final_sod_conflicts_dataframe = pd.DataFrame()
        final_sod_conflicts_dataframe_role = pd.DataFrame()
        final_sod_conflicts_dataframe_user = pd.DataFrame()

        # Dataframe initialization for Activity Mapping
        final_activity_mapping_dataframe = pd.DataFrame()
        final_activty_mapping_dataframe_role = pd.DataFrame()
        final_activity_mapping_dataframe_user = pd.DataFrame()

        cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data, osam_roles_to_user = read_osam_input_excel(
            cloud_rule_file, role_design_files, user_to_role_file);
        cloud_role_matrix_columns = list(cloud_role_matrix_data.columns)
        cloud_role_matrix_role_columns = cloud_role_matrix_columns[13::]

        # osam role validation
        final_sod_conflicts_dataframe_role, final_activty_mapping_dataframe_role = osam_role_conflict_validation(
            cloud_role_matrix_data, osam_sod_ruleset_data,
            osam_sod_rule_data, cloud_role_matrix_role_columns,
            final_sod_conflicts_dataframe_role, final_activty_mapping_dataframe_role, activity_mapping_flag)

        if user_to_role_file != 'NA':
            osam_roles_to_user_dict = osam_roles_to_user.set_index('User Name').T.to_dict()
            df1 = pd.DataFrame()
            df2 = pd.DataFrame()
            df_list = split_dict_equally(osam_roles_to_user_dict, 10)
            res = []
            start = time.perf_counter()
            with concurrent.futures.ProcessPoolExecutor() as executor:
                for i in df_list:
                    results = executor.submit(split_process, i, osam_roles_to_user,
                                              cloud_role_matrix_data, osam_sod_ruleset_data, osam_sod_rule_data,
                                              final_sod_conflicts_dataframe_user,
                                              final_activity_mapping_dataframe_user, activity_mapping_flag)
                    res.append(results)
                for f in concurrent.futures.as_completed(res):
                    df1 = df1.append(f.result()[0], ignore_index=True)
                    df2 = df2.append(f.result()[1], ignore_index=True)

            final_sod_conflicts_dataframe_user = df1
            final_activity_mapping_dataframe_user = df2
            finish = time.perf_counter()
            logging.info("Finished Parallel process" + str(round(finish - start, 2)))
            print(f'Finished kiran2 check in {round(finish - start, 2)} second(s)')

    # SOD Conflict dataframe aggregation
        final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.append(final_sod_conflicts_dataframe_role)
        if user_to_role_file != 'NA':
            final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.append(final_sod_conflicts_dataframe_user)

        # Activity Mapping dataframe aggregation
        final_activity_mapping_dataframe = final_activity_mapping_dataframe.append(final_activty_mapping_dataframe_role)
        if user_to_role_file != 'NA':
            final_activity_mapping_dataframe = final_activity_mapping_dataframe.append(
                final_activity_mapping_dataframe_user)

        if not final_sod_conflicts_dataframe.empty:
            final_sod_conflicts_dataframe['Object Type/App Stripe'] = str('Privilege-') + final_sod_conflicts_dataframe[
                'APP-NAME'].astype(str)

            final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.drop(['INHERITED-ROLE-HIERARCHY', 'APP-NAME'],
                                                                               axis=1)

        columns_rename_dict = {'Activity Name': 'Activity',
                               'Security Object Display Name': 'Privilege Display name',
                               'Security Object Technical Name': 'Privilege Tech Name', 'Priority': 'Rule Priority',
                               'Description': 'Rule Description', 'Impact': 'Rule Impact'}

        if not final_sod_conflicts_dataframe.empty:
            final_sod_conflicts_dataframe.rename(columns=columns_rename_dict, inplace=True)

        final_column_order = ["Role or User Name", "Object Type", "Rule Name", "Activity", "Privilege Display name",
                              "Privilege Tech Name", "Navigation Path", "Role Name", "Object Type/App Stripe",
                              "Rule Priority",
                              "Rule Description", "Rule Impact"]

        # final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.reindex(columns=final_column_order)

        final_op_ordered_dataframe = pd.DataFrame()
        if not final_sod_conflicts_dataframe.empty:
            final_op_ordered_dataframe = final_sod_conflicts_dataframe[final_column_order]
        else:
            final_op_ordered_dataframe = pd.DataFrame(columns=final_column_order)

        final_op_ordered_dataframe_activity_mapping = pd.DataFrame()
        if activity_mapping_flag:
            final_activity_mapping_dataframe['Object Type/App Stripe'] = str('Privilege-') + \
                                                                         final_activity_mapping_dataframe[
                                                                             'APP-NAME'].astype(str)

            final_activity_mapping_dataframe = final_activity_mapping_dataframe.drop(
                ['INHERITED-ROLE-HIERARCHY', 'APP-NAME'],
                axis=1)

            columns_rename_dict = {'Activity Name': 'Activity',
                                   'Security Object Display Name': 'User Function Name',
                                   'ENTITLEMENT-NAME': 'Technical Function Name', 'Role or User Name': 'Object Name',
                                   'Object Type/App Stripe': 'SOD Object Type'}

            final_activity_mapping_dataframe.rename(columns=columns_rename_dict, inplace=True)

            final_column_order = ["Object Name", "Object Type", "Activity", "User Function Name",
                                  "Technical Function Name", "Navigation Path", "SOD Object Type"]

            # final_sod_conflicts_dataframe = final_sod_conflicts_dataframe.reindex(columns=final_column_order)

            final_op_ordered_dataframe_activity_mapping = final_activity_mapping_dataframe[final_column_order]

        blob_client = blob_service_client.get_blob_client(container_name, output_file_sod, )
        writer = io.BytesIO()
        # dataframe_blobdata.to_excel(writer, sheet_name='SOD Conflicts Report', index=False)
        # writer = pd.ExcelWriter(output_file)
        final_op_ordered_dataframe.to_excel(writer, sheet_name='SOD Conflicts Report', index=False)

        if activity_mapping_flag:
            writer1 = io.BytesIO()
            blob_client_1 = blob_service_client.get_blob_client(container_name, output_file_activity)
            final_op_ordered_dataframe_activity_mapping.drop_duplicates(keep='first',inplace=True)
            final_op_ordered_dataframe_activity_mapping.to_excel(writer1, sheet_name='Activity Mapping Report',
                                                                 index=False)
            blob_client_1.upload_blob(writer1.getvalue(), overwrite=False)

        # writer.save()
        blob_client.upload_blob(writer.getvalue(), overwrite=True)
        rem_time = time.time() - start_time
        logging.info("Completed in " + str(rem_time))

        print("--- %s seconds ---" % (time.time() - start_time))
        print('Done')
        logging.info("Completed osam processing")
        # response_dict = {}
        # response_dict['status'] = 'done all'
        # response_dict['final_output'] = final_op_ordered_dataframe.to_json
        collection.find_one_and_update({"_id":req_id}, {"$set" : {"taskStatus" : "Completed"}})
        return 'done all'
    except Exception as ex:
        print('Exception happened >> ', ex)
        collection.find_one_and_update({"_id":req_id}, {"$set" : {"taskStatus" : "Failure"}})
        # response_dict = {}
        # response_dict['status'] = 'failure'
        # response_dict['error'] = ex
        return ex


