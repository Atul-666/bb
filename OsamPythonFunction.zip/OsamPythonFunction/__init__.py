import logging

import azure.functions as func
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
from . import oracle_osam as osam


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    #name = req.params.get('name')
    #if not name:
    #print('starting')
    response = ''
    req_body = req.get_json()
    try:
        
        cloud_rule_file = req_body.get('sodRules')
        role_design_files = req_body.get('roleDesign')
        user_to_role_file = req_body.get('userRole')
        output_file_sod = req_body.get('outputFileSod')
        output_file_activity = req_body.get('outputFileActivity')
        is_sod_needed_flag = req_body.get('is_sod_needed_flag')
        is_activity_needed_flag = req_body.get('is_activity_needed_flag')
        req_id = req_body.get('reqId')
        response = osam.osam_processing(cloud_rule_file, role_design_files, user_to_role_file, str(is_sod_needed_flag), str(is_activity_needed_flag),
                    output_file_sod, output_file_activity,req_id)
    except ValueError:
        pass
    #else:
        #name = req_body.get('name')

    #from pathlib import Path
    #data= str(Path.home()) + "/data"
    #final_output = data + output_file
    if response == 'done all':
        return func.HttpResponse(f"Hello, the output file is present in {output_file_sod} & {output_file_activity} in blob container.")
        # return func.HttpResponse(response['final_output'])
    else:
        return func.HttpResponse(
            "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response." + str(response),
             status_code=200
        )
        # return func.HttpResponse(response['error'])
